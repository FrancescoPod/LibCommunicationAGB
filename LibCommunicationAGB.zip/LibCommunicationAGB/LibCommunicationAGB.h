#ifndef COMMUNICATION_H
#define COMMUNICATION_H
#define CodeA  "A!x!A"
#define CodeB  "B!x!B"
#define CodeC  "C!x!C"
#define CodeD  "D!x!D"
#define CodeE  "E!x!E"
#define CodeF  "F!x!F"
#define CodeG  "G!x!G"
#define CodeH  "H!x!H"
#define CodeI  "I!x!I"
#define CodeL  "L!x!L"
#define CodeM  "M!x!M"
#define CodeN  "N!x!N"
#define CodeO  "O!x!O"
#define CodeP  "P!x!P"
#define CodeQ  "Q!x!Q"
#define CodeR  "R!x!R"
#define CodeS  "S!x!S"
#define CodeT  "T!x!T"
#define CodeU  "U!x!U"
#define CodeV  "V!x!V"
#define CodeZ  "Z!x!Z"
#include <Arduino.h>
class SingleSender {
  public:
  SingleSender(String code);
  void debug();
  void addData(String val);
  void flush();
  private:
  String message;
  String _code;
  bool error;
  String error_message = "Null";
};
class MultiSender {
  public:
  MultiSender(String codes[],int len);
  void debug();
  void addData(String vals[]);
  void flush();
  private:
  int _len;
  String _codes[21];
  String message[21];
  bool error;
  String error_message = "Null";
  
 

};
class Receiver{
  public:
  Receiver(String c);
  String read();
  void debug(); 
  private:
  bool error;
  String error_message = "Null";
  String _c;
 
  
};



#endif
