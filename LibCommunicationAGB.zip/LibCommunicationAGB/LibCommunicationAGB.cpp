#include "LibCommunicationAGB.h"
#include <Arduino.h>
// Single sender method and constructor.


SingleSender::SingleSender(String code) {
  if (code.indexOf("x") > -1) {
    _code = code;
  }
  else {
    error = true;
    error_message = "Invalid code.";
  }
}
void SingleSender::debug() {
  Serial.print("Errors: ");
  Serial.print(error);
  Serial.print(" Motivation => ");
  Serial.println(error_message);
  Serial.print("Code: ");
  Serial.println(_code);
  Serial.print("Current output value: ");
  Serial.println(message);
}
void SingleSender::flush() {
  Serial.println(message);
  delay(50);
}
void SingleSender::addData(String val) {
  message = _code;
  message.replace("x", val);
}

bool check(String str[], int len) {
  bool res = true;
  for (int i = 0; i < len; i++) {
    if (!(str[i].indexOf("x") > -1)) {
      res = false;
    }
  }
  return res;
}

// Multiple sender method and constructor


MultiSender::MultiSender(String code[], int len) {
  if (len <= 21) {
    if (check(code, len)) {
      // copy array;
      for (int i = 0; i < len; i++) {
        _codes[i] = code[i];
      }
      _len = len;
    }
    else {
      error = true;
      error_message = "One of the codes is wrong. There is something wrong in the first argument of this method.";
    }

  }
  else {
    error = true;
    error_message = "Exceeded the maximum number of elements [21].";
  }
}
void MultiSender::addData(String vals[]) {
  for (int i = 0; i < _len; i++) {
    String c = _codes[i];
    c.replace("x", vals[i]);
    message[i] = c;
  }
}
void MultiSender::debug() {
  Serial.print("Errors: ");
  Serial.print(error);
  Serial.print(" Motivation => ");
  Serial.println(error_message);
  Serial.println("Codes: ");
  for (int i = 0; i < _len; i++) {
    Serial.println(_codes[i]);
  }
  Serial.println("Current output values: ");
  for (int i = 0; i < _len; i++) {
    Serial.println(message[i]);
  }
}
void MultiSender::flush() {
  String m = "";
  for (int i = 0; i < _len; i++) {
    if (i == _len - 1) {
      m = m + message[i];
    }
    else {
      m = m + message[i] + " ";
    }


  }
  Serial.println(m);
  delay(50);
}
bool checkR(String str) {
  bool res = true;
  if (!(str.indexOf("x") > -1)) {
    res = false;
  }
  return res;
}
Receiver::Receiver(String c) {
  if (checkR(c)) {
    _c = c;
  }
  else {
    error = true;
    error_message = "Code is invalid.";
  }

}
String getBetween(String strSource, String strStart, String strEnd) {
  if (strSource.indexOf(strStart)>-1 && strSource.indexOf(strEnd)>-1)
  {
    int Start, End;
    Start = strSource.indexOf(strStart, 0);
    End = strSource.indexOf(strEnd, Start);
    return strSource.substring(Start+strStart.length(), End);
  }
  return "";
}
String Receiver::read() {
  String mes = Serial.readString();
  String code_f = _c.substring(3);
  String code_s = _c.substring(0, 2);
  String a= getBetween(mes,code_s,code_f);
  return a;
}
void Receiver::debug() {
  Serial.print("Errors: ");
  Serial.print(error);
  Serial.print(" Motivation => ");
  Serial.println(error_message);
  Serial.print("Code: ");
  Serial.println(_c);;
}
